<?php $__env->startSection('contentdefault'); ?>
<section class="section-intro bg-faded text-xs-center">
 <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
          <h3 class="wp wp-1">FReS-TA</h3>
         <p class="lead wp wp-2"><?php echo e($data['pg1']); ?></p>
         <p class="lead wp wp-2"><?php echo e($data['pg2']); ?></p>
         <br>
      </div>
    </div>
 </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appdefault', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>