<?php $__env->startSection('content'); ?>

    <!-- Hero Section
    ================================================== -->

    <header class="jumbotron bg-inverse text-xs-center" role="banner">
      <div class="container">
         <br>
        <h3><?php echo e($data['title']); ?></h3>
      </div>
    </header>

    <?php echo $__env->yieldContent('contentdefault'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>